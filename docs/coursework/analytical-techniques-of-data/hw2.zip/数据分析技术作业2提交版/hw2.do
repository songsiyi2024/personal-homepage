*homework 2
*数学科学学院 宋思逸 2400010816
cd E:\C\课内课程\大二下课程\数据分析技术\hw2
use "hw2_data(1).dta",clear //打开主数据集，清空内存

rename (a2 a3a a3b a8a a8b) (gender birthy birthm income earned_inc) //修改变量名
label variable gender "性别"
label variable birthy "您的出生日期-年"
label variable birthm "您的出生日期-月"
label variable income "您个人去年（2012）全年的总收入是多少"
label variable earned_inc "您个人去年（2012）全年的职业/劳动收入是多少" //对变量赋予标签

label define gender_lbl 1 "男" 2 "女" -3 "拒绝回答缺失值" -2 "不知道缺失值" -1 "不适用缺失值" //定义值标签规则
label values gender gender_lbl //应用值标签规则

recode gender birthy birthm (-3 -2 -1=.) //缺失值处理1
recode income earned_inc (9999997 9999998 9999999=.) //缺失值处理2

gen age = 2013 - birthy //生成年龄变量
label variable age "年龄" //变量标签

preserve //保留当前数据集
keep if age >= 21 & age <= 60 & income <=200000 & earned_inc <=200000 //数据筛选
save "hw2_clean.dta" , replace //保存文件
restore //恢复当前数据集

estpost summarize age income earned_inc if gender == 1
estimates store Male //分析男性数据

estpost summarize age income earned_inc if gender == 2
estimates store Female //分析女性数据

esttab Male Female using "E:\C\课内课程\大二下课程\数据分析技术\hw2\desc_stats.rtf", replace main(mean %8.2f) aux(sd %8.2f) mtitle("男性" "女性") title("表1: 分性别描述性统计") nonumbers label //表格生成


qui summarize income, detail
local p99 = r(p99) //我们剔除掉过高的outliers

twoway ///
    (scatter income age if gender == 1 & income < `p99', mcolor(blue%10) msize(small) msymbol(circle)) ///
    (lowess income age if gender == 1 & income < `p99', lcolor(black) lwidth(thick)), ///
    title("男性总收入与年龄关系") ///
    xtitle("年龄") ///
    ytitle("总收入") ///
    legend(off) ///
    scheme(s1color) ///
    name(male_income_age, replace)
	
graph save "male_income_age.gph", replace
graph export "male_income_age.png", replace
	//男性图表

twoway ///
    (scatter income age if gender == 2 & income < `p99', mcolor(red%10) msize(small) msymbol(circle)) ///
    (lowess income age if gender == 2 & income < `p99', lcolor(black) lwidth(thick)), ///
    title("女性总收入与年龄关系") ///
    xtitle("年龄") ///
    ytitle("总收入") /// 
    legend(off) ///
    scheme(s1color) ///
    name(female_income_age, replace)
	
graph save "female_income_age.gph", replace
graph export "female_income_age.png", replace
	//女性图表
	
	
qui summarize earned_inc, detail
local p99 = r(p99) //同样剔除outliers

twoway  ///
	(scatter earned_inc age if gender == 1 & earned_inc < `p99', mcolor(blue%10) msize(small) msymbol(circle)) ///
	(lowess earned_inc age if gender == 1 & earned_inc < `p99', lcolor(black) lwidth(thick)), ///
	title("男性职业/劳动收入与年龄关系") ///
	xtitle("年龄") ///
	ytitle("职业/劳动收入") ///
	legend(off) ///
	scheme(s1color) ///
	name(male_earnedincome_age, replace)
	
graph save "male_earnedincome_age.gph", replace
graph export "male_earnedincome_age.png", replace
	//男性图表

twoway  ///
	(scatter earned_inc age if gender == 2 & earned_inc <`p99', mcolor(red%10) msize(small) msymbol(circle)) ///
	(lowess earned_inc age if gender == 2 & earned_inc <`p99', lcolor(black) lwidth(thick)), ///
	title("女性职业/劳动收入与年龄关系") ///
	xtitle("年龄") ///
	ytitle("职业/劳动收入") ///
	legend(off) ///
	scheme(s1color) ///
	name(female_earnedincome_age, replace)
	
graph save "female_earnedincome_age.gph", replace
graph export "female_earnedincome_age.png", replace
	//女性图表
	

preserve
foreach v of varlist _all{
	rename `v' `v'_2013
}	
save hw2_clean_2013.dta, replace
restore
*利用foreach命令进行重命名

gen female = .
replace female = 0 if gender == 1
replace female = 1 if gender == 2

estpost ttest income earned_inc, by(female)
esttab using "ttest_gender.rtf", replace ///
	cells("mu_1(label(male mean)) mu_2(label(female mean)) b se t p") ///
	title("T-test: Income Variables by Gender")
*t检验收入与性别关系，并用estout相关命令导出

gen age_group = .
replace age_group = 1 if age >= 20 & age <= 30
replace age_group = 2 if age >= 31 & age <= 40
replace age_group = 3 if age >= 41 & age <= 50
replace age_group = 4 if age >= 51 & age <= 60
*按照年龄段分成4个组别

label define agegrp 1 "20-30岁" 2 "31-40岁" 3 "41-50岁" 4 "51-60岁"
label values age_group agegrp
label define genderlbl 1 "男性" 2 "女性"
label values gender genderlbl
*加上年龄和性别标签

preserve
keep if inrange(age, 20, 60)
keep if gender == 1 | gender == 2
collapse (mean) meanincome = income, by(age_group gender)
list age_group gender meanincome, sepby(age_group)
graph bar meanincome, over(gender) over(age_group) ///
    ytitle("总收入均值") ///
    title("不同年龄组男性和女性总收入均值") ///
    legend(label(1 "总收入均值")) ///
	name(meanincome_age_gender, replace)

graph save "meanincome_age_gender.gph", replace
graph export "meanincome_age_gender.png", replace
restore
*分组后，通过年龄和性别做collapse并绘制条形图