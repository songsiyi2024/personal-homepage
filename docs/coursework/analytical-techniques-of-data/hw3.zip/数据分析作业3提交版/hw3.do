*数据分析技术第三次作业 宋思逸 2400010816
cd "E:\C\课内课程\大二下课程\数据分析技术\hw3"
use "hw3.dta" , clear

*只考虑农业户口和非农业户口
gen hukou=.
replace hukou = 0 if qa2 == 1
replace hukou = 1 if qa2 == 3
label define hukoulbl 0 "农业户口" 1 "非农业户口"
label values hukou hukoulbl

*重分类最高学历
gen edu4=.
replace edu4 = 1 if qc1 == 1 | qc1 == 2
replace edu4 = 2 if qc1 == 3
replace edu4 = 3 if qc1 == 4
replace edu4 = 4 if qc1 == 5 | qc1 == 6 | qc1 == 7 | qc1 == 8
label define edu4lbl 1 "小学及以下" 2 "初中" 3 "高中/中专/技校/职高" 4 "大专及以上"
label values edu4 edu4lbl

replace qk601 = . if qk601<0
gen ln_income = ln(qk601+1)
gen age2 = qa1age^2

*户口类型按性别
asdoc tabulate hukou gender if hukou !=. , row col save(hukou_gender) replace
*户口类型按最高学历
asdoc tabulate hukou edu4 if hukou !=., row col save(hukou_edu) replace

*模型1
reg ln_income i.hukou if hukou != ., baselevels
est store model1
outreg2 using "model1_regression.doc", replace ///
    ctitle("model1") ///
    bdec(3) sdec(3)

*模型2
reg ln_income i.hukou i.gender i.edu4 qa1age age2 if hukou != ., baselevels
est store model2
outreg2 using "model2_regression.doc", replace ///
    ctitle("model2") ///
    bdec(3) sdec(3)

*异方差检验
reg ln_income i.hukou i.gender i.edu4 qa1age age2 ///
    if hukou != ., baselevels
estat hettest //BP
estat imtest, white //white

*模型调整
reg ln_income i.hukou i.gender i.edu4 qa1age age2 ///
    if hukou != ., robust baselevels
est store model3
outreg2 using "model3_robust.doc", replace ///
    ctitle("model3") ///
    bdec(3) sdec(3)
	
	
*中介分析
replace qk101 = 0 if qk101 < 0
replace qk102 = 0 if qk102 < 0
replace qk103 = 0 if qk103 < 0
replace qk601 = . if qk601 < 0
gen wage_income = qk101 + qk102 + qk103
gen ln_wageincome=ln(wage_income+1)
*总效应模型：户口类型->总收入
reg ln_income i.hukou i.gender i.edu4 qa1age age2, robust baselevels
est store total_effect

*path a 户口类型->工资性收入
reg ln_wageincome i.hukou i.gender i.edu4 qa1age age2, ///
    robust baselevels
est store path_a

*直接效应：户口类型+工资性收入->总收入
reg ln_income i.hukou ln_wageincome i.gender i.edu4 qa1age age2, ///
    robust baselevels
est store direct_effect

esttab total_effect path_a direct_effect using "mediation_regression.rtf", ///
    replace se ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    stats(N r2, labels("N" "R-squared")) ///
    title("工资性收入的中介效应分析")

*khb
khb regress ln_income hukou || ln_wageincome, concomitant(i.gender i.edu4 qa1age age2) summary disentangle

*交互效应
gen region=.
* 东部地区：
* 辽宁、吉林、黑龙江、北京、天津、河北、上海、江苏、浙江、福建、山东、广东、海南
replace region = 1 if inlist(provcd, 11, 12, 13, 21, 22, 23)
replace region = 1 if inlist(provcd, 31, 32, 33, 35, 37, 44, 46)
* 中部地区：
* 山西、安徽、江西、河南、湖北、湖南
replace region = 2 if inlist(provcd, 14, 34, 36, 41, 42, 43)
* 西部地区：
* 内蒙古、广西、重庆、四川、贵州、云南、西藏、陕西、甘肃、青海、宁夏、新疆
replace region = 3 if inlist(provcd, 15, 45, 50, 51, 52, 53)
replace region = 3 if inlist(provcd, 54, 61, 62, 63, 64, 65)
label define regionlbl ///
    1 "东部" ///
    2 "中部" ///
    3 "西部"
label values region regionlbl

reg ln_income i.hukou##i.region i.gender i.edu4 qa1age age2, ///
    robust baselevels
est store interaction_model
outreg2 using "interaction_region.doc", replace ///
    ctitle("户口类型×地区") ///
    bdec(3) sdec(3)






