*homework 1
*数学科学学院 宋思逸 2400010816
cd E:\C\课内课程\大二下课程\数据分析技术\hw1
use "charls_sample.dta",clear //打开主数据集，清空内存

destring ID householdID communityID, replace //将字符转为数值类型
describe

**下面的内容是为了将stata中使用describe命令之后显示的内容导出到表格，使其工整美观而加上的，借助了AI工具帮助导出excel文件后粘贴到word文档。后面的没有进行这一操作，是因为这里的数据太多了，没有表格线会显得比较混乱**
/*
tempname memhold
tempfile vardesc

postfile `memhold' ///
    str32 varname ///
    str12 type ///
    str20 format ///
    str20 vallab ///
    str80 varlabel ///
    using `vardesc', replace

foreach v of varlist _all {
    local t : type `v'
    local f : format `v'
    local vl : value label `v'
    local lab : variable label `v'
    
    post `memhold' ("`v'") ("`t'") ("`f'") ("`vl'") ("`lab'")
}

postclose `memhold'

use `vardesc', clear
export excel using "variable_description.xlsx", firstrow(variables) replace*/
**导出部分到此结束

keep if ba002_1 >= 1930 & ba002_1 <= 1979
recode ba002_1 (1930/1939=1 "1930s") ///
(1940/1949=2 "1940s") ///
(1950/1959=3 "1950s") ///
(1960/1969=4 "1960s") ///
(1970/1979=5 "1970s"), gen(cohort_group)
label variable cohort_group "出生世代分组"
/*asdoc*/ summarize ba002_1, detail //数值变量查看统计相关数据
/*asdoc*/ tabulate cohort_group //离散型
preserve
gen male = (rgender==1)
collapse (mean) male, by(cohort_group) // 按照代际计算男性占比
/*asdoc*/ list
restore
gen age = 2011 - ba002_1
label variable age
/*asdoc*/ summarize age, detail

gen zodiac = mod((ba002_1 - 1930) + 1200, 12) //通过求余数获取生肖编号
label var zodiac "生肖属相" //标签
label define zodiac_lbl ///
    0 "马" 1 "羊" 2 "猴" 3 "鸡" 4 "狗" 5 "猪" ///
    6 "鼠" 7 "牛" 8 "虎" 9 "兔" 10 "龙" 11 "蛇" //定义标签表
label values zodiac zodiac_lbl //应用标签表
/*asdoc*/ tabulate zodiac //查看分布并导出

recode bd001 (1=0) (2=3) (3=6) (4=9) (5=12) (6=15) (7=16) (8=19), gen(edu_years) //按照编号对应受教育年限并生成edu_years
label variable edu_years "受教育年限" //标签
/*asdoc*/ bysort rgender: summarize edu_years

count if be001 == 1 | be001 == 2 | be001 == 3 //结婚，结婚但暂时分居，分居都算是在婚
/*asdoc*/ table cohort be001 //直接列表